These files are in support of the "Refactoring Workbook", by William C. Wake, ISBN 0321109295, copyright Addison Wesley Professional, 2003. 

All files are for educational purposes only, with no express or implied warranty. 

The home for this book is http://www.xp123.com/rwb

Contact William Wake, William.Wake@acm.org.

July 12, 2003
