
 Contents
------------------------------------------------
 1. Eclipse Setup 
 2. Ecal Build and Test.
 3. Product Startup 
 4. Running Ecal

 =========================
 1.  Eclipse 3.x  Setup
 =========================

These instructions should help you setup your development environment.
Pre-requisites: must have ant, and java 1.4 installed.

 (1) Create your CVS connection using this following settings and parameters
 
        Window | Preferences | General | Enable SSH ... select the check box. 

	 	:extssh:<SOUREFORGE ID>@cvs.sourceforge.net:/cvsroot/ecal
    

 (2) Select the ecal-java module, right click and select "Checkout Project"
 
 (3) Hum your favorite song 3 times (optional but recommended).

 (4) Add the following directories as source roots.
     Right click on the project
          
        Properties | Java Build Path | Source | Add Folder... 
          
        and add each of these directories.   
	     -  regression
	     -  src
	     -  scripts
	     -  src_fit
     

 (5)  Add a junit.jar and clover.jar to your ant runtime library list.
 		
 	Window | Preferences |Ant | Runtime | Aditional Classpath Entries
 			
      The best place to get the jar is from the junit plug-in which you
      an find in your eclipse installation directory.
       	
       	eclipse/plugins/org.junit_3.8.1/junit.jar


 =======================
  2. Ecal Build and Test.
 =======================

These steps will ensure that your environment is setup correctly and
that the product will compile and run in that environment.

 (1) Copy file ecal/scripts/ecal.properties.txt to ecal/scripts/ecal.properties

 (2) edit file ecal\scripts\ecal.properties
    
     For example:
      
        appl.path=c:\\eclipse\\workspace\\ecal-java
        appl.url=http://localhost:9090/ECal
        appl.pathsep=\\
        db.....

 
 (3) Run the default ant target.
 
 	ant test 


 =======================
 3. Product Startup 
 =======================

These steps will start the servers that make up the product and allow you
to use the product and run the FIT tests.

	IDE Startup
	-----------
	There is a java main that can be run that will startup 
	both the servers (fitnesse port 7070 & ecal on port 9090).

	src/alltests/RestartServers.java
	

 ===================== 
 4. Running Ecal
 ===================== 

To use Ecal open your browser to the following URL.

 	http://localhost:9090/ECal
 	
 	or use shortcut gotoEcal.html in the install directory

To run the FIT tests against the Ecal server open you browser to the
following URL.

 	http://localhost:7070/CalendarPaths.CalendarTests

 	or use shortcut gotoFitnesse.html in the install directory
 	

-Thats all.
If you have questions
send them to xpcinci@objectwind.com 


