NOTE: For your convenience, the listings for the "automating" chapter have been
combined with the listings from chapter 3 ("sampling"). The listings for both 
chapter 3 ("sampling") and 5 ("automating") can all be found in the "sampling"
module. 

###
