DROP TABLE CUSTOMER;
CREATE TABLE CUSTOMER (lastname varchar primary key, 
    firstname varchar);
